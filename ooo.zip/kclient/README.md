# Kclient

Simple Iframe wrapper for the [KasmVNC](https://github.com/kasmtech/KasmVNC) protocol to add audio and file management.
